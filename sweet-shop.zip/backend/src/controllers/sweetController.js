const { sweets } = require('../models/sweet');
exports.addSweet = (req,res)=>{
  sweets.push({ id:sweets.length+1, ...req.body });
  res.json({message:'added'});
};
exports.getSweets = (req,res)=>res.json(sweets);
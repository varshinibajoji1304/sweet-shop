const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { users } = require('../models/user');
const SECRET = 'secretkey';

exports.register = async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  users.push({ id: users.length+1, username, password: hashed, role:'USER' });
  res.json({ message:'registered' });
};

exports.login = async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username===username);
  if(!user) return res.status(401).json({message:'invalid'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({message:'invalid'});
  const token = jwt.sign({ role:user.role }, SECRET);
  res.json({ token });
};
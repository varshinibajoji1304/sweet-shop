const jwt = require('jsonwebtoken');
const SECRET='secretkey';
exports.authMiddleware=(req,res,next)=>{
  const t=req.headers.authorization;
  if(!t) return res.status(401).json({message:'no token'});
  req.user=jwt.verify(t,SECRET);
  next();
};
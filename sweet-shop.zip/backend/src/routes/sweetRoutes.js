const express=require('express');
const {addSweet,getSweets}=require('../controllers/sweetController');
const {authMiddleware}=require('../middleware/authMiddleware');
const r=express.Router();
r.get('/',authMiddleware,getSweets);
r.post('/',authMiddleware,addSweet);
module.exports=r;
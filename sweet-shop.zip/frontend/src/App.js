import './style.css';
export default function App(){return <h1>Sweet Shop</h1>;}
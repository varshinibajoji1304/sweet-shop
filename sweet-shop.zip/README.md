Sweet Shop Management System
Run backend and frontend separately.
